/*
 -------------------------------------
 File:    heap.c
 Project: A9T3
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-03-30
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "heap.h"

/* this compare two key values a and b, return -1 if a<b, 0 if a=b, 1 if a>b  */
int cmp(KEYTYPE a, KEYTYPE b) {
	if (a < b)
		return -1;
	else if (a == b)
		return 0;
	else
		return 1;
}

/* this compare two data values a and b, return -1 if a<b, 0 if a=b, 1 if a>b  */
int cmp_data(DATA a, DATA b) {
	if (a < b)
		return -1;
	else if (a == b)
		return 0;
	else
		return 1;
}

/* create and return a heap data structure
 to instantiate and return the pointer of the above heap
 structure,  size=0, capacity=4, allocate memory space to
 hold array of
 elements of the capacity and store pointer in data
 */
HEAP* new_heap(int capacity) {
	HEAP *hp = (HEAP*) malloc(sizeof(HEAP));
	hp->capacity = capacity;
	hp->size = 0;
	hp->hnap = (HNODE*) malloc(sizeof(HNODE) * capacity);
	return hp;
}

void heapify_up(HEAP *heap, int index) {
	int parent_index;
	HNODE val = *(heap->hnap + index); //ending value
	HNODE parent;
	while (index) {
		parent_index = (index - 1) >> 1;
		parent = *(heap->hnap + parent_index);
		if (cmp(parent.key, val.key) == -1) {
			//parent is already less than child, nothing to do
			break;
		} else {
			//swap values
			*(heap->hnap + index) = *(heap->hnap + parent_index);
			index = parent_index;
		}
	}
	//put val in proper place
	*(heap->hnap + index) = val;
}

void heapify_down(HEAP *heap, int index) {
	int curr_index = 0;
	int child_index =
			2 * curr_index + 2 < heap->size ?
					cmp(heap->hnap[2 * curr_index + 1].key,
							heap->hnap[2 * curr_index + 2].key) == -1 ?
							2 * curr_index + 1 : 2 * curr_index + 2
			:
			2 * curr_index + 1 < heap->size ? 2 * curr_index + 1 : curr_index;
	while (cmp(heap->hnap[curr_index].key, heap->hnap[child_index].key) == 1) {
		// Swap the current node and its child node
		HNODE temp = heap->hnap[curr_index];
		heap->hnap[curr_index] = heap->hnap[child_index];
		heap->hnap[child_index] = temp;

		curr_index = child_index;
		child_index =
				2 * curr_index + 2 < heap->size ?
						cmp(heap->hnap[2 * curr_index + 1].key,
								heap->hnap[2 * curr_index + 2].key) == -1 ?
								2 * curr_index + 1 : 2 * curr_index + 2
				:
				2 * curr_index + 1 < heap->size ?
						2 * curr_index + 1 : curr_index;
	}

}

/* this inserts the given node data a into the heap;
 * When the heap size is equal to the capacity,
 * the inserting process needs first to expand data
 * array by doubling its amount. This may need to
 * copy the data of old array to new array, secondly
 *  insert the new data element into the end of the
 * array, heapify and update size.*/
void insert(HEAP *heap, HNODE new_node) {
	//check if heap is full
	if (heap->size == heap->capacity) {
		heap->capacity *= 2; //double the capacity
		HNODE *temp = realloc(heap->hnap, sizeof(HNODE) * heap->capacity);
		if (temp) {
			heap->hnap = temp;
		} else {
			temp = malloc(sizeof(HNODE) * heap->capacity);
			if (temp) {
				memcpy(temp, heap->hnap, sizeof(HNODE) * heap->size);
				free(heap->hnap);
				heap->hnap = temp;
			} else {
				printf("array resize failed\n");
			}
		}
	}
	*(heap->hnap + heap->size) = new_node;
	//heapify up
	heapify_up(heap, heap->size);
	heap->size++;

}

/* this gets the data element of minimum key and delete the element from the binary heap.
 * When the heap size  is no more than a quarter of the capacity, it needs to shrink the data
 * array by half to free the unused memory space. */
HNODE extract_min(HEAP *heap) {
	//make the last node the root
	HNODE min = *(heap->hnap);
	heap->hnap[0] = heap->hnap[heap->size - 1];
	free(heap->hnap + heap->size - 1);

	heapify_down(heap, 0);

	//shrink if needed
	if (heap->size == (heap->capacity / 2)) {
		heap->capacity /= 2;
		HNODE *temp = realloc(heap->hnap, sizeof(HNODE) * heap->capacity);
		if (temp) {
			heap->hnap = temp;
		} else {
			temp = malloc(sizeof(HNODE) * heap->capacity);
			if (temp) {
				memcpy(temp, heap->hnap, sizeof(HNODE) * heap->size);
				free(heap->hnap);
				heap->hnap = temp;
			} else {
				printf("array resize failed\n");
			}
		}
	}
	heap->size--;

	return min;
}

/* this decreases the key value of given element by index to new_key_value */
void decrease_key(HEAP *heap, int node_index, KEYTYPE key_value) {
	if (!heap)
		return;
	if (node_index > heap->size)
		return;

	heap->hnap[node_index].key = key_value;

	heapify_up(heap, node_index);
	heapify_down(heap, node_index);
}

/* this finds and returns the first index of heap node of given data d*/
int find_index(HEAP *heap, DATA value) {
	int found = 0;
	int index = 0;
	int answer = -1;
	HNODE curr;
	while (found == 0 && index < heap->size) {
		curr = *(heap->hnap + index);
		if (cmp_data(curr.data, value) == 0) {
			found = 1;
			answer = index;
		} else if (cmp_data(curr.data, value) == -1) {
			//if the current data (the next minimum) is greater than the value we're searching
			//for and we still haven't found it then it doesn't exist
			break;
		} else {
			index++;
		}
	}
	return answer;
}

/* this displays data elements in heap by index ordering.  */
void display_heap(HEAP *hp) {
	printf("\nsize:%d\ncapacity:%d\n", hp->size, hp->capacity);
	printf("(index, key, data): ");
	int i;
	for (i = 0; i < hp->size; i++) {
		printf("(%d %d %d) ", i, hp->hnap[i].key, hp->hnap[i].data);
		if (i % 10 == 9)
			printf("\n");
	}
	printf("\n");
}

