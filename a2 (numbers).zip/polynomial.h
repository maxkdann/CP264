/*
 -------------------------------------
 File:    polynomial.h
 Project: polynomial
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-01-26
 -------------------------------------
 */

#include <stdio.h>
#include <math.h>

#define EPSILON 0.000001

/**
 *
 * @param p, coefficients of the polynomial
 * @param n, number of terms in the polynomial
 * @param x, the x value
 */
void display_polynomial(float p[], int n, float x) {
	float *ptr;
	ptr = &p[0];
	for (int i = 0; i < n; i++) {
		printf("%.2f*%.2f^%d", *ptr, x, n - 1 - i);
		if (i != n - 1) {
			printf("+");
		}
		ptr++;
	}
}
/**
 * computes a polynomial at value x using horner's algorithm
 * @param p, coefficients of the polynomial
 * @param n, number of coefficients in the polynomial
 * @param x, the x value
 * @return the polynomial evaluated at value x
 */
float horner(float p[], int n, float x) {
	float result = p[0];

	for (int i = 1; i < n; i++) {
		result = result * x + p[i];
	}
	
	//to prevent the rounding up to -0.00, very small tolerance value
	if (result < 5 * EPSILON && result > 5 * -EPSILON) {
		result = 0.00;
	}
	return result;
}

/**
 * returns the absolute value of a float
 * @param f
 * @return
 */
float absolute(float f) {
	if (f < 0) {
		return -1 * f;
	} else {
		return f;
	}
}
/**
 *
 * @param p, coefficients of the polynomial
 * @param n, number of coeffiecients of the polynomial
 * @param a, first endpoint
 * @param b, second endpoint
 * @return mid, the midpoint that is the root
 */
float bisection(float p[], int n, float a, float b) {
	float val;
	float mid = b;
	int is_approx = 0;

	while (is_approx != 1) {
		mid = (a + b) / 2; //calculate the midpoint of the interval
		val = horner(p, n, mid); //calculate the function value at the midpoint
		if (absolute(mid - a) < EPSILON || val == 0.000000) {
			is_approx = 1; //approx root found
		} else if (val * horner(p, n, a) < 0) {
			b = mid;
		} else {
			a = mid;
		}

	}

	return mid;
}

