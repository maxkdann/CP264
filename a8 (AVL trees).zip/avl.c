#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "avl.h"

// A utility functions
int max(int a, int b) {
	return (a > b) ? a : b;
}
/**
 * returns the height of a node
 * @param node
 * @return
 */
int height(TNODE *node) {
	int height;

	height = 0;
	if (node != NULL)
		height = node->height;

	return (height);
}

/**
 * returns the balance factor of a node
 * @param node
 * @return
 */
int balance_factor(TNODE *np) {
	return (np == NULL) ? 0 : height(np->left) - height(np->right);
}
/**
 * checks that the balance factor of each node is between -1 and 1
 * @param node, node to check
 * @return 1 if balanced otherwise 0
 */
int is_avl(TNODE *node) {
	int is_balanced = 0;
	if (node == NULL || node->height == 1) {
		//base case: no node or a leaf so no children
		is_balanced = 1;
	} else if (abs(height(node->left) - height(node->right)) > 1) {
		//base case: left or right subtree is too deep
		is_balanced = 0;
	} else {
		is_balanced = is_avl(node->left) && is_avl(node->right);
	}
	return is_balanced;
}

TNODE* rotate_right(TNODE *y) {
	TNODE *x = y->left;
	TNODE *t2 = x->right;
	//perform rotation
	x->right = y;
	y->left = t2;
	//update heights
	y->height = max(height(y->left), height(y->right)) + 1;
	x->height = max(height(x->left), height(x->right)) + 1;

	return x;
}

TNODE* rotate_left(TNODE *x) {
	TNODE *y = x->right;
	TNODE *t2 = y->left;
	//perform rotation
	y->left = x;
	x->right = t2;
	//update heights
	x->height = max(height(x->left), height(x->right)) + 1;
	y->height = max(height(y->left), height(y->right)) + 1;

	return y;
}

void insert(TNODE **rootp, char *name, float score) {
// 1. Perform the normal BST insertion
	if (*rootp == NULL) {
		TNODE *np = (TNODE*) malloc(sizeof(TNODE));
		if (np != NULL) {
			strcpy(np->data.name, name);
			np->data.score = score;
			np->height = 1;
			np->left = NULL;
			np->right = NULL;
			*rootp = np;
		}
		return;
	}

	//TNODE *root = *rootp;
	if (strcmp(name, (*rootp)->data.name) < 0)
		insert(&(*rootp)->left, name, score);
	else if (strcmp(name, (*rootp)->data.name) > 0)
		insert(&(*rootp)->right, name, score);
	else
		//already in tree
		return;

// 2. update height of this root node
	(*rootp)->height = max(height((*rootp)->left), height((*rootp)->right)) + 1;
// 3. Get the balance factor of this ancestor node to check whether this node became unbalanced
	int balance = balance_factor((*rootp));
// 4. re-balance if not balanced
	if (balance == 2 && balance_factor((*rootp)->left) >= 0) {
		(*rootp) = rotate_right((*rootp));
	} else if (balance == 2 && balance_factor((*rootp)->left) < 0) {
		(*rootp)->left = rotate_left((*rootp)->left);
		(*rootp) = rotate_right((*rootp));
	} else if (balance == -2 && balance_factor((*rootp)->right) <= 0) {
		(*rootp) = rotate_left((*rootp));
	} else if (balance == -2 && balance_factor((*rootp)->right) > 0) {
		(*rootp)->right = rotate_right((*rootp)->right);
		(*rootp) = rotate_left((*rootp));
	}

}

void delete(TNODE **rootp, char *name) {
	TNODE *root = *rootp;
	TNODE *np;

	if (root == NULL)
		return;

	if (strcmp(name, root->data.name) == 0) {
		if (root->left == NULL && root->right == NULL) {
			free(root);
			*rootp = NULL;
		} else if (root->left != NULL && root->right == NULL) {
			np = root->left;
			free(root);
			*rootp = np;
		} else if (root->left == NULL && root->right != NULL) {
			np = root->right;
			free(root);
			*rootp = np;
		} else if (root->left != NULL && root->right != NULL) {
			np = extract_smallest_node(&root->right);
			np->left = root->left;
			np->right = root->right;
			free(root);
			*rootp = np;
		}
	} else {
		if (strcmp(name, root->data.name) < 0) {
			delete(&root->left, name);
		} else {
			delete(&root->right, name);
		}
	}

// If the tree had only one node then return
	if (*rootp == NULL)
		return;

	root = *rootp;

	// 2. update height of this root node
	(*rootp)->height = max(height((*rootp)->left), height((*rootp)->right)) + 1;
	// 3. Get the balance factor of this ancestor node to check whether this node became unbalanced
	int balance = balance_factor((*rootp));
	// 4. re-balance if not balanced
	if (balance == 2 && balance_factor((*rootp)->left) >= 0) {
		(*rootp) = rotate_right((*rootp));
	} else if (balance == 2 && balance_factor((*rootp)->left) < 0) {
		(*rootp)->left = rotate_left((*rootp)->left);
		(*rootp) = rotate_right((*rootp));
	} else if (balance == -2 && balance_factor((*rootp)->right) <= 0) {
		(*rootp) = rotate_left((*rootp));
	} else if (balance == -2 && balance_factor((*rootp)->right) > 0) {
		(*rootp)->right = rotate_right((*rootp)->right);
		(*rootp) = rotate_left((*rootp));
	}
}

// following functions are from bst.c of a7
TNODE* extract_smallest_node(TNODE **rootp) {
	TNODE *tnp = *rootp;
	TNODE *parent = NULL;
	if (tnp == NULL) {
		return NULL;
	} else {
		while (tnp->left) {
			parent = tnp;
			tnp = tnp->left;
		}
		if (parent == NULL)
			*rootp = tnp->right;
		else
			parent->left = tnp->right;
		tnp->left = NULL;
		tnp->right = NULL;
		return tnp;
	}
}

TNODE* search(TNODE *root, char *name) {
	TNODE *tp = root;
	while (tp) {
		if (strcmp(name, tp->data.name) == 0) {
			return tp;
		} else if (strcmp(name, tp->data.name) < 0)
			tp = tp->left;
		else
			tp = tp->right;
	}
	return NULL;
}

void clean_tree(TNODE **rootp) {
	if (*rootp) {
		TNODE *np = *rootp;
		if (np->left)
			clean_tree(&np->left);
		if (np->right)
			clean_tree(&np->right);
		free(np);
	}
	*rootp = NULL;
	;
}

void display_inorder(TNODE *root) {
	if (root) {
		if (root->left)
			display_inorder(root->left);
		printf("(%s %3.1f) ", root->data.name, root->data.score);
		if (root->right)
			display_inorder(root->right);
	}
}

void display_inorder_lines(TNODE *root) {
	if (root) {
		if (root->left)
			display_inorder_lines(root->left);
		printf("%-15s%.1f\n", root->data.name, root->data.score);
		if (root->right)
			display_inorder_lines(root->right);
	}
}

void display_tree(TNODE *root, int prelen) {
	if (root) {
		int i;
		for (i = 0; i < prelen; i++)
			printf("%c", ' ');
		printf("%s", "|___");
		printf("%s %.1f %d\n", root->data.name, root->data.score, root->height);
		display_tree(root->right, prelen + 4);
		display_tree(root->left, prelen + 4);
	}
}
