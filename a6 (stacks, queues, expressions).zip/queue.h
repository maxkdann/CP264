/*
 -------------------------------------
 File:    queue.h
 Project: A6T1
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-03-02
 -------------------------------------
 */
#ifndef QUEUE_H_
#define QUEUE_H_
#include "common.h"

typedef struct queue {
	NODE *front;
	NODE *rear;
} QUEUE;

void enqueue(QUEUE *qp, NODE *np);
NODE* dequeue(QUEUE *qp);
void clean_queue(QUEUE *qp);

#endif /* QUEUE_H_ */
