/*
 -------------------------------------
 File:    expression.c
 Project: A6T3
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-03-02
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "queue.h"
#include "stack.h"
#include "expression.h"

/*
 * auxiliary function
 */
int get_priority(char op) {
	if (op == '/' || op == '*' || op == '%')
		return 1;
	else if (op == '+' || op == '-')
		return 0;
	else
		return -1;
}

/*
 * auxiliary function
 */
int type(char c) {
	if (c >= '0' && c <= '9')
		return 0;
	else if (c == '/' || c == '*' || c == '%' || c == '+' || c == '-')
		return 1;
	else if (c == '(')
		return 2;
	else if (c == ')')
		return 3;
	else
		return 4;
}

QUEUE infix_to_postfix(char *infixstr) {
	char *p = infixstr;
	QUEUE queue = { 0 }; //result postfix expression in queue
	STACK stack = { 0 }; // auxiliary stack
	int num = 0;
	NODE *temp = { 0 };
	while (*p) {
		//case of number character, get whole number then add to queue
		if (*p >= '0' && *p <= '9') {
			//use horner's algorithm to get the operand
			num = *p - '0';
			while ((*(p + 1) >= '0' && *(p + 1) <= '9')) {
				num = num * 10 + *(p + 1) - '0';
				p++;
			}
			enqueue(&queue, new_node(num, 0));
		}
		//open bracket, push to stack
		else if (*p == '(') {
			push(&stack, new_node(*p, type(*p)));
		}
		//close bracket, pop stack until ( is found
		else if (*p == ')') {
			while (stack.top && (temp = pop(&stack))->type != 2) {
				enqueue(&queue, temp); //add stack elements to output
			}
		}
		//operator
		else if (type(*p) == 1) {
			//push onto stack if priority of op is greater than top
			while (stack.top
					&& get_priority(*p) <= get_priority(stack.top->data)) {
				enqueue(&queue, pop(&stack));
			}
			push(&stack, new_node(*p, type(*p)));

		}
		//else ignore
		p++;
	}
	//finally pop each node and insert it to queue
	while (stack.top) {
		enqueue(&queue, pop(&stack));
	}

	return queue;
}

int evaluate_postfix(QUEUE queue) {
	STACK stack = { 0 };
	NODE *p = queue.front;
	int type = 0;
	int result = 0;
	while (p) {
		type = p->type;
		if (type == 0) {			//operand
			push(&stack, new_node(p->data, 0));
		} else if (type == 1) {			//operator
			NODE *b = pop(&stack);
			NODE *a = pop(&stack);
			NODE *c = new_node(0, 0);
			switch (p->data) {
			case '+':
				c->data = a->data + b->data;
				break;
			case '-':
				c->data = a->data - b->data;
				break;
			case '*':
				c->data = a->data * b->data;
				break;
			case '/':
				c->data = a->data / b->data;
				break;
			}
			push(&stack, c);
		}
		p = p->next;
	}
	if (stack.top != NULL) {
		result = stack.top->data;
	}
	return result;
}

int evaluate_prefix(char *infixstr) {
	QUEUE post = infix_to_postfix(infixstr);
	int result = evaluate_postfix(post);
	clean_queue(&post);
	return result;
}
