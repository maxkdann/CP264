/*
 -------------------------------------
 File:    queue.c
 Project: A6T1
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-03-02
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "queue.h"

void enqueue(QUEUE *qp, NODE *np) {
	//case 1 q is empty, update front and rear
	if (qp->front == NULL) {
		qp->front = np;
		qp->rear = np;
	}
	//case 2 q has at least one element, update rear->next and then update rear
	else {
		qp->rear->next = np;
		qp->rear = np;
	}
	return;
}

NODE* dequeue(QUEUE *qp) {
	NODE *removed = NULL;
	if (qp->front != NULL) {
		removed = qp->front;
		qp->front = qp->front->next;
		removed->next = NULL;
	}

	return removed;
}

void clean_queue(QUEUE *qp) {
	clean(&qp->front);
	/*
	 NODE *cur;
	 while (qp->front != NULL) {
	 cur = qp->front;
	 qp->front = qp->front->next;
	 free(cur);

	 }
	 qp->front = qp->rear = NULL;
	 */
}
