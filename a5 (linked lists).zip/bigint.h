/*
 -------------------------------------
 File:    bigint.h
 Project: A5T3
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-02-26
 -------------------------------------
 */
#ifndef BIGINT_H_
#define BIGINT_H_

#include "dllist.h"

typedef struct bigint {
	struct node *start;
	struct node *end;
} BIGINT;

/*
 * This takes a big number in digit string and coverts
 * and returns it in BIGINT type.
 *
 */
BIGINT bigint(char *digitstr);

/*
 *  This prints the digits of the big_number.
 */
void display_bigint(BIGINT big_number);

/*
 *  This cleans the doubly linked list of the big_numberp.
 */
void clean_bigint(BIGINT *big_numberp);

/*
 *  This adds the two BIGINT operants and return the resulted sum BIGINT.
 */
BIGINT add(BIGINT oprand1, BIGINT oprand2);

/*
 *  This computes nth Fibonacci number F(n) using the above the add function and returns F(n) in BIGINT type
 */
BIGINT Fibonacci(int n);

#endif /* BIGINT_H_ */
