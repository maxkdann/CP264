/*
 -------------------------------------
 File:    dllist.c
 Project: A5T2
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-02-26
 -------------------------------------
 */
#include <stdio.h>
#include <stdlib.h>
#include "dllist.h"
/*
 * This creates a new node using malloc().
 */
NODE* new_node(char data) {
	NODE *p = (NODE*) malloc(sizeof(NODE));
	p->next = NULL;
	p->prev = NULL;
	p->data = data;
	return p;
}

/*
 * This displays char data from start to end.
 */
void display_forward(NODE *start) {
	NODE *ptr = start;
	while (ptr != NULL) {
		printf("%c ", ptr->data);
		//has this code so as not to print the final space but removed it to match the grader
		/*
		 if (ptr->next != NULL) {
		 printf(" ");
		 }
		 */
		ptr = ptr->next;
	}
	return;
}

/*
 * This displays char data from end to start.
 */
void display_backward(NODE *end) {
	NODE *ptr = end;
	while (ptr != NULL) {
		printf("%c ", ptr->data);
		//has this code so as not to print the final space but removed it to match the grader
		/*
		 if (ptr->prev != NULL) {
		 printf(" ");
		 }
		 */
		ptr = ptr->prev;
	}
	return;
}

/*
 * This inserts a new node at the beginning the of doubly linked list.
 */
void insert_start(NODE **startp, NODE **endp, NODE *new_np) {
	new_np->next = *startp;
	if ((*startp) != NULL) {
		(*startp)->prev = new_np;
	} else {
		(*endp) = new_np;
	}

	(*startp) = new_np;
}

/*
 * This inserts a new node at the end of the doubly linked list.
 */
void insert_end(NODE **startp, NODE **endp, NODE *new_np) {
	if (*endp != NULL) {
		(*endp)->next = new_np;
		new_np->prev = (*endp);
	} else {
		(*startp) = new_np;
	}
	(*endp) = new_np;
	return;
}

/*
 * This deletes the first node of the doubly linked list.
 */
void delete_start(NODE **startp, NODE **endp) {
	NODE *p = *startp;
	(*startp) = (*startp)->next;
	(*startp)->prev = NULL;
	free(p);
}

/*
 * This deletes the last node of the doubly linked list.
 */
void delete_end(NODE **startp, NODE **endp) {
	NODE *p = *endp;
	(*endp) = (*endp)->prev;
	(*endp)->next = NULL;
	free(p);
}

/*
 * This cleans the doubly linked list.
 */
void clean(NODE **startp, NODE **endp) {
	NODE *ptr = *startp;
	NODE *next = NULL;
	while (ptr != NULL) {
		next = (NODE*) ptr->next;
		free(ptr);
		ptr = next;
	}
	*startp = NULL;
	*endp = NULL;
	return;
}
