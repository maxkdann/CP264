Name: Maxwell Dann
ID: 190274440
Email: dann4440@mylaurier.ca
WorkID: CP264-a3
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: A - assignment, Q - question 
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid: [self-evaluation/total/marker-evaluation]

A3

Q1 My string functions
Q1.1 str_length()                         [3/3/*]
Q1.2 word_count()                         [3/3/*]
Q1.3 lower_case()                         [3/3/*]
Q1.4 trim()                               [3/3/*]

Q2 My word processor
Q2.1 Data structure for stop words        [3/3/*]
Q2.2 set_stopword()                       [3/3/*]
Q2.3 contain_word()                       [3/3/*]
Q2.4 str_contain_word()                   [3/3/*]
Q2.5 process_word(()                      [3/3/*]
Q2.6 save_to_file()                       [3/3/*]

Total:                                   [30/30/*]

Copy and paste the console output of your public test in the following. This will help markers to evaluate your program if it fails the testing.  

Q1 output:
C:\cp264\a3>gcc mystring.c mystring_main.c -o q1

C:\cp264\a3>q1
str:"     This Is    a Test   "
str_length(str):25
word_count(str):4
trim(str):"this is a test"
str_length(trim(str)):14


Q2 output:
C:\cp264\a3>gcc mystring.c myword.c myword_main.c -o q2

C:\cp264\a3>q2
stop word checker:ready
is_stopword(is):1
is_stopword(hello):0
word processing:done
line count:2
word count:10
keyword count:3
first:1
test:2
second:1
saving result to file:done