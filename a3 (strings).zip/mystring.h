/*
 -------------------------------------
 File:    mystring.h
 Project: Mystring
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-02-02
 -------------------------------------
 */
#ifndef MYSTRING_H_
#define MYSTRING_H_

int str_length(char*);
int word_count(char*);
void lower_case(char*);
void trim(char*);

#endif /* MYSTRING_H_ */
