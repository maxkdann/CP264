/*
 -------------------------------------
 File:    hash.c
 Project: A9T1
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-03-23
 -------------------------------------
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "hash.h"
/* hash function that hash name string to an integer of modular htsize */
int hash(char *word) {
	unsigned int hash = 0, i;
	for (i = 0; word[i] != '\0'; i++) {
		hash = 31 * hash + word[i];
	}
	return hash % htsize;
}

/* create dynamically a hash node and set name and value and return the point */
HTNODE* new_hashnode(char *name, int value) {
	HTNODE *new = (HTNODE*) malloc(sizeof(HTNODE));
	strcpy(new->name, name);
	new->value = value;
	new->next = NULL;
	return new;
}

/* create dynamically a chained hash table of the size */
HASHTABLE* new_hashtable(int size) {
	//allocate space for hash table
	HASHTABLE *new = (HASHTABLE*) malloc(sizeof(HASHTABLE));
	//allocate space to hold array of hashnode pointers
	new->hnp = (HTNODE**) malloc(sizeof(HTNODE**) * size);
	//initialize each pointer in the array
	int i;
	for (i = 0; i < size; i++) {
		*(new->hnp + i) = NULL;
	}

	new->size = size;
	new->count = 0;
	return new;
}

/* search the hash table and return the pointer of found hashnode */
HTNODE* search(HASHTABLE *ht, char *name) {
	int i = hash(name);
	HTNODE *p = *(ht->hnp + i);
	if (p != NULL) {
		while (p != NULL) {
			if (strcmp(p->name, name) == 0) {
				return p;
			}
			p = p->next;
		}
	}
	return NULL;
}

/* insert hashnode np to hash table
 * when the named hashnode exists, update the hashnode's value by np->value, free np, return 0;
 * otherwise insert into the hash table, return 1
 */
int insert(HASHTABLE *ht, HTNODE *np) {
	char *name = np->name;
	int i = hash(name);
	HTNODE *p = *(ht->hnp + i), *pp = NULL; //pp for previous pointer
	//empty linked list
	if (p == NULL) {
		*(ht->hnp + i) = np;	//set node as the leading node
	} else if (strcmp(name, p->name) == 0) {
		//hashnode exists
		p->value = np->value;
		free(np);
		return 0;
	} else {
		while (p && strcmp(name, p->name) > 0) {
			pp = p;
			p = p->next;
		}

		if (pp == NULL) {
			*(ht->hnp + i) = np;
		} else
			pp->next = np;
		np->next = pp;
	}
	ht->count++;
	return 1;
}

/* delete hashnode by name. If the named hash node exists, delete it and return 1;
 * otherwise return 0
 */
int delete(HASHTABLE *ht, char *name) {
	int i = hash(name);
	HTNODE *p = *(ht->hnp + i), *pp = NULL;

	if (p != NULL) {
		while (p && strcmp(name, p->name) > 0) {
			pp = p;
			p = p->next;
		}

		if (p && strcmp(name, p->name) == 0) {
			if (pp)
				pp->next = p->next;
			else
				*(ht->hnp + i) = NULL;

			free(p);
			ht->count--;
			return 1;
		}
	}
	return 0;
}

// you can use this function in your program
void clean_hash(HASHTABLE **htp) {
	if (*htp == NULL)
		return;
	HASHTABLE *ht = *htp;
	HTNODE *p, *temp;
	int i;
	for (i = 0; i < ht->size; i++) {
		p = ht->hnp[i];
		while (p) {
			temp = p;
			p = p->next;
			free(temp);
		}
		ht->hnp[i] = NULL;
	}
	free(ht->hnp);
	ht->hnp = NULL;
	*htp = NULL;
}

// you can use this function in your program
void display_hashtable(HASHTABLE *ht, int option) {
	int i = 0;
	HTNODE *p;
	if (option == 0) {
		printf("size:  %d\n", ht->size);
		printf("count: %d\n", ht->count);
		printf("hash data:\nindex: list of the data elements");
		for (i = 0; i < ht->size; i++) {
			p = *(ht->hnp + i);
			if (p)
				printf("\n%2d: ", i);

			while (p) {
				printf("(%s, %d) ", p->name, p->value);
				p = p->next;
			}
		}
		printf("\n");
	} else {

		for (i = 0; i < ht->size; i++) {
			p = *(ht->hnp + i);
			while (p) {
				printf("%s=%d\n", p->name, p->value);
				p = p->next;
			}
		}

	}

}
