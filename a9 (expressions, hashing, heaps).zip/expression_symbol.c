/*
 -------------------------------------
 File:    expression_symbol.c
 Project: A9T2
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-03-23
 -------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "queue.h"
#include "stack.h"
#include "expression_symbol.h"
/*
 * auxiliary function
 */
int get_priority(char op) {
	if (op == '/' || op == '*' || op == '%')
		return 1;
	else if (op == '+' || op == '-')
		return 0;
	else
		return -1;
}
/*
 * auxiliary function
 */
int type(char c) {
	if (c >= '0' && c <= '9')
		return 0;
	else if (c == '/' || c == '*' || c == '%' || c == '+' || c == '-')
		return 1;
	else if (c == '(')
		return 2;
	else if (c == ')')
		return 3;
	else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
		return 5;
	else
		return 4;
}
/*
 * convert infix expression string to postfix expression queue,
 * getting symbol values from the hash table
 */
QUEUE infix_to_postfix_symbol(char *infixstr, HASHTABLE *ht) {
	QUEUE queue = { 0 };
	STACK stack = { 0 };
	char *p = infixstr;
	int num = 0;
	NODE *temp = { 0 };

	//int i = 0;
	while (*p) {
		char symbol[11] = { 0 };
		//case of number character, get whole number then add to queue
		if (*p >= '0' && *p <= '9') {
			//use horner's algorithm to get the operand
			num = *p - '0';
			while ((*(p + 1) >= '0' && *(p + 1) <= '9')) {
				num = num * 10 + *(p + 1) - '0';
				p++;
			}
			enqueue(&queue, new_node(num, 0));
		}
		//open bracket, push to stack
		else if (*p == '(') {
			push(&stack, new_node(*p, type(*p)));
		}
		//close bracket, pop stack until ( is found
		else if (*p == ')') {
			while (stack.top && (temp = pop(&stack))->type != 2) {
				enqueue(&queue, temp); //add stack elements to output
			}
		}

		//operator
		else if (type(*p) == 1) {
			//push onto stack if priority of op is greater than top
			while (stack.top
					&& get_priority(*p) <= get_priority(stack.top->data)) {
				enqueue(&queue, pop(&stack));
			}
			push(&stack, new_node(*p, type(*p)));

		}
		//letter
		else if (type(*p) == 5) {
			//get full symbol
			strncat(symbol, p, 1);
			//symbol[i] = *p - 'a';
			//i++;
			while ((*(p + 1) >= 'a' && *(p + 1) <= 'z')
					|| (*(p + 1) >= 'A' && *(p + 1) <= 'Z')) {
				strncat(symbol, (p + 1), 1);
				//i++;
				p++;
			}

			//search hash table by the symbol name for its value
			HTNODE *result = search(ht, symbol);
			enqueue(&queue, new_node(result->value, 0));
		}
		p++;

	}
	//finally pop each node and insert it to queue
	while (stack.top) {
		enqueue(&queue, pop(&stack));
	}
	return queue;
}

//evaluate the expression and return the result
int evaluate_postfix(QUEUE queue) {
	STACK stack = { 0 };
	NODE *p = queue.front;
	int type = 0;
	int result = 0;
	while (p) {
		type = p->type;
		if (type == 0) {			//operand
			push(&stack, new_node(p->data, 0));
		} else if (type == 1) {			//operator
			NODE *b = pop(&stack);
			NODE *a = pop(&stack);
			NODE *c = new_node(0, 0);
			switch (p->data) {
			case '+':
				c->data = a->data + b->data;
				break;
			case '-':
				c->data = a->data - b->data;
				break;
			case '*':
				c->data = a->data * b->data;
				break;
			case '/':
				c->data = a->data / b->data;
				break;
			}
			push(&stack, c);
		}
		p = p->next;
	}
	if (stack.top != NULL) {
		result = stack.top->data;
	}
	return result;
}

/*
 * evaluate symbolic infix expression,
 * call queue = infix_to_postfix_symbol(char *infixstr, HASHTABLE *ht);
 * then call evaluate_postfix(QUEUE queue);
 */
int evaluate_infix_symbol(char *infixstr, HASHTABLE *ht) {
	QUEUE queue = infix_to_postfix_symbol(infixstr, ht);
	int result = evaluate_postfix(queue);
	return result;
}

/*
 * parse statement symbol=expression, to get left-side symbol string, and
 * evaluate the right side expression using evaluate_infix_symbol(char *infixstr, HASHTABLE *ht);
 * insert the symbol and its value into hash table
 */
int resolve_symbol(char *statement, HASHTABLE *ht) {
	char name[10] = { 0 };
	char *dest = strstr(statement, "=");
	if (dest)
		*dest = '\0';
	else
		dest = statement;
	strcpy(name, statement);

	if ((name[0] >= 'a' && name[0] <= 'z')
			|| (name[0] >= 'A' && name[0] <= 'Z')) {

		int value = evaluate_infix_symbol(dest + 1, ht);

		if (value == 99999)  // escape value
			return 2;
		else {
			insert(ht, new_hashnode(name, value));
		}
		return 1;
	}
	return 0;
}
