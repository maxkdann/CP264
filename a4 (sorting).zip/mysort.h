/*
 -------------------------------------
 File:    mysort.h
 Project: mysort
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-02-09
 -------------------------------------
 */
#ifndef MYSORT_H_
#define MYSORT_H_

void select_sort(int *a, int left, int right);
void quick_sort(int *a, int left, int right);
void swap(int *first, int *second);

typedef enum {
	FALSE = 0, TRUE = 1
} BOOLEAN;

BOOLEAN is_sorted(int *a, int left, int right);
#endif /* MYSORT_H_ */
