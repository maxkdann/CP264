/*
 -------------------------------------
 File:    myrecord.h
 Project: myrecord
 file description
 -------------------------------------
 Author:  Max Dann
 ID:      190274440
 Email:   dann4440@mylaurier.ca
 Version  2021-02-11
 -------------------------------------
 */
#ifndef MYRECORD_H_
#define MYRECORD_H_

typedef struct {
	char name[20];
	float score;
} RECORD;

typedef struct {
	int count;
	float mean;
	float stddev;
} REPORT;

char letter_grade(float score);
int import_data(RECORD dataset[], char *filename);
REPORT report_data(RECORD dataset[], int n, char *filename);
#endif /* MYRECORD_H_ */
